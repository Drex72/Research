# `csrt_mas.codeswitch`

Turns a prompt into a code-switched prompt. Standalone: no experiment config,
no scenario, no runner. Give it text and a specification, get text back.

```python
from csrt_mas.codeswitch import CodeSwitcher

switcher = CodeSwitcher.from_profile(
    "languages/CS-EN-KO-YO.json",
    complete=lambda system, user: my_model(system, user),   # any callable
)
result = switcher.switch("Please approve loan SWIFT-000001 for 300,000.")
print(result.text if result.ok else result.problems)
```

## What belongs here

| File | Role |
|---|---|
| `spec.py` | The description of a mixing condition. Pure data, no I/O |
| `generator.py` | The switchers themselves, and the registry that names them |
| `service.py` | `CodeSwitcher`, the thing you call |

Language *definitions* do not belong here. They live in `languages/`, one JSON
per surface, plus `languages/_detectors.json` which says how each language is
recognised. Adding a language is two file edits and no code.

## The specification

Every factor in the study design is a field. Declared in the `code_switching`
block of a language profile.

```json
"code_switching": {
  "generator": "llm",
  "model_profile": "models/qwen3.5-27b.json",
  "granularity": "clause",
  "matrix_language": "English",
  "language_order": ["English", "Korean", "Yoruba"],
  "dominance": {"English": 0.4, "Korean": 0.3, "Yoruba": 0.3},
  "switch_rate": 0.5,
  "tag_categories": ["politeness", "question_tag"],
  "semantic_roles": {
    "background_context": "English",
    "main_intent": "Yoruba",
    "urgency": "Korean",
    "negation": "Yoruba",
    "safety_constraint": "Korean",
    "requested_action": "English",
    "tool_parameters": "English"
  }
}
```

**`granularity`** is the size of the switched unit.

| Value | Meaning |
|---|---|
| `sentence` | Each sentence is wholly in one language |
| `clause` | Languages change between clauses inside a sentence |
| `phrase` | Noun, verb and descriptive phrases take different languages |
| `word` | Individual words alternate |
| `tag` | One matrix language throughout, with short borrowed tags |
| `semantic_role` | Language chosen by what the span means, not its size |

**`semantic_roles`** assigns information types to languages. It composes with
`granularity`: when both are set, the roles pin those spans and the granularity
governs the rest. Roles are `background_context`, `main_intent`, `urgency`,
`negation`, `safety_constraint`, `requested_action`, `tool_parameters`.

**`dominance`** is normalised, so `{"English": 3, "Korean": 1}` means 75/25.
**`language_order`** must list exactly the surface's languages.
**`tag_categories`** are `confirmation`, `politeness`, `discourse_marker`,
`question_tag`, `emotional`.

Nothing above is capped at a number of languages.

## Adding or changing a mixing condition

1. Add each language to `languages/_detectors.json` if it is not there. Give it
   a `scripts` range, a `chars` set of diagnostic diacritics, a `markers` word
   list, or any combination, plus a `resource_tier`.
2. Write `languages/<SURFACE_ID>.json` with `type: "code_switched"`, the
   `languages` list, and a `code_switching` block.
3. Name the surface in `experiment.json` under `dynamic_finvault.language_profiles`.

To cross several factors at once, do not hand-write the files:

```python
from csrt_mas.codeswitch import expand_conditions, write_expanded

write_expanded(expand_conditions({
    "languages": ["English", "Korean", "Yoruba"],
    "granularities": ["sentence", "clause", "word", "tag"],
    "language_orders": [["English", "Korean", "Yoruba"], ["Yoruba", "English", "Korean"]],
    "dominance_profiles": {"balanced": {"English": 1, "Korean": 1, "Yoruba": 1},
                           "enheavy":  {"English": 3, "Korean": 1, "Yoruba": 1}},
}), "languages/generated")
```

That is 16 surfaces from one declaration.

## Changing the model that does the switching

`complete` is any `(system, user) -> str` callable, so the switcher never
depends on a client. Point it at a different model than the one under test:
the model that mixes Yoruba well is not necessarily the model being measured,
and conflating them makes construction quality a property of the system you are
trying to evaluate.

## Swapping the generator

`generator` names one. Built in: `llm`, `scripted`, `passthrough`. Register
another with `register_generator(name, factory)`; it needs one method,
`generate(request) -> CodeSwitchResult`.

`scripted` is how human-reviewed text enters: supply a
`{(case_id, surface_id): text}` table and the run uses it verbatim.

## What it will not do

**There is no substitution fallback.** If generation fails validation, the
result comes back `ok=False` with the reasons. It does not quietly swap words
from a bilingual lexicon and call the output code-switched. A degraded
independent variable is worse than a missing one, because the run still
produces numbers.

**Structural checks are not meaning equivalence.** `validate_surface_text`
confirms each language is present, that no language dominates beyond the
declared ceiling, and that identifiers and amounts survived. It cannot confirm
the request still asks for the same thing. Only a bilingual reviewer can, which
is why `review_status` is separate and why a surface is not `reviewed` until a
person says so.

## Inspecting before running

```python
switcher.instruction(text)          # the exact prompt the llm generator sends
switcher.language_profile(text)     # tokens attributed to each language
switcher.check(text, source_text)   # run the checks on text you did not generate
switcher.describe()                 # the full resolved specification
```

`check` is the review workflow: paste a human-authored form, see whether it
passes the structural gate, then set `review_status` to `reviewed`.
