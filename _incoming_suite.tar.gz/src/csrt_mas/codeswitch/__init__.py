"""Code-switching as a standalone, pluggable module.

Give it a prompt and a specification; it returns a code-switched prompt.

It has no dependency on the experiment runner, the scenario layer, or any
particular model client. The experiment plugs it in; so can anything else.

    from csrt_mas.codeswitch import CodeSwitcher

    switcher = CodeSwitcher.from_profile(
        "languages/CS-EN-KO-YO.json", complete=my_model_call
    )
    result = switcher.switch("Please approve loan SWIFT-000001 for 300,000.")
    if result.ok:
        print(result.text)
    else:
        print(result.problems)

The specification covers every factor in the study design: which languages, in
what order, in what proportion, at what switching granularity (sentence,
clause, phrase, word, tag) and with which semantic roles assigned to which
language. The generator itself is swappable by name, so an LLM switcher, a
scripted human-authored set, and anything registered later are
interchangeable.
"""

from __future__ import annotations

from .generator import (
    GENERATORS,
    CodeSwitchGenerator,
    CodeSwitchRequest,
    CodeSwitchResult,
    LLMCodeSwitchGenerator,
    PassthroughGenerator,
    ScriptedGenerator,
    build_instruction,
    register_generator,
)
from .service import CodeSwitcher
from .spec import (
    GRANULARITIES,
    SEMANTIC_ROLES,
    TAG_CATEGORIES,
    CodeSwitchSpec,
    CodeSwitchSpecError,
    expand_conditions,
    load_code_switch_spec,
    write_expanded,
)

__all__ = [
    "GENERATORS",
    "GRANULARITIES",
    "SEMANTIC_ROLES",
    "TAG_CATEGORIES",
    "CodeSwitchGenerator",
    "CodeSwitchRequest",
    "CodeSwitchResult",
    "CodeSwitchSpec",
    "CodeSwitchSpecError",
    "CodeSwitcher",
    "LLMCodeSwitchGenerator",
    "PassthroughGenerator",
    "ScriptedGenerator",
    "build_instruction",
    "expand_conditions",
    "load_code_switch_spec",
    "register_generator",
    "write_expanded",
]
